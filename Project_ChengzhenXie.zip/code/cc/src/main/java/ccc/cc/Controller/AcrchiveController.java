package ccc.cc.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpSession;

@Controller
public class AcrchiveController {
	
	 @RequestMapping("/index")
		public ModelAndView index( HttpSession session,Model model){
		   String string = (String)session.getAttribute("username");
		   if(string==null) {
			   model.addAttribute("users","Please login");
		   }else {
			   model.addAttribute("users", "welcome"+"  "+string);
		   }
	
	        ModelAndView mv = new ModelAndView("index");
	        return mv;
	    }
	 @RequestMapping("/Recommend")
		public ModelAndView game(){
	        ModelAndView mv = new ModelAndView("Recommend");
	        return mv;
	    }
	 @RequestMapping("/forget")
		public ModelAndView forget(){
	        ModelAndView mv = new ModelAndView("forget");
	        return mv;
	    }
	 @RequestMapping("/test")
		public ModelAndView test(){
	        ModelAndView mv = new ModelAndView("test");
	        return mv;
	    }
	 
	@RequestMapping("/chenggong")
		public ModelAndView zhandianchaxun(){
	        ModelAndView mv = new ModelAndView("chenggong");
	        return mv;
	    }
	@RequestMapping("/back")
		public ModelAndView back(){
	        ModelAndView mv = new ModelAndView("back");
	        return mv;
	    }
/*	@RequestMapping("/Services1")
	public ModelAndView Services1k(){
        ModelAndView mv = new ModelAndView("Services1");
        return mv;
    }*/
}
