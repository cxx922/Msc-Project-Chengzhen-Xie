package ccc.cc.Controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import ccc.cc.Service.*;
import ccc.cc.model.*;

@RestController
public class RegController {
	@Autowired
	Testservice ts;
	@GetMapping("/register")
		public ModelAndView index(){
	        ModelAndView mv = new ModelAndView("register");
	        return mv;
	    }
    @RequestMapping("/register")
	//@RequestParam("username") String username,@RequestParam("password") String userpassword
	    public ModelAndView Login(HttpServletRequest request,Model model, HttpSession session){
	      
			int vali=3;
			   User u = new User();
			   u.setUsername(request.getParameter("username"));
			   u.setPhone(request.getParameter("phone"));
			   u.setPassword(request.getParameter("password"));
		
			   System.out.println("????????");
			   System.out.println(u.getUsername());
			   System.out.println(u.getPassword());
		/*	  if(u.getPassword().length()>8) {
				  
			   model.addAttribute("msg1", "Please input the account number and password below 8 digits");
			   ModelAndView mv = new ModelAndView("reg");
				 return mv;   
			  }else if(u.getUsername().length()>8){
				  model.addAttribute("msg1", "Please input the account number and password below 8 digits");
				  ModelAndView mv = new ModelAndView("reg");
				  return mv; 
			  }*/
			  ts.newp(u);
			   System.out.println("？？？？？？？");
		//	   System.out.println(u2.getUsername());
		//	   System.out.println(u2.getPassword());
		 //      session.setAttribute("name", 1);

				 ModelAndView mv = new ModelAndView("login");
				 return mv;   
		
			   
	
	
			   }
     public int validate(User u) {
    	 if(u.getPassword()==null&&u.getUsername()==null) {
    		 return 1;
    	 }else {
    		 return 0;
    	 }
     }
        	
 

}