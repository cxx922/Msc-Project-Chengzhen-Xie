package ccc.cc.Controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import ccc.cc.Service.*;
import ccc.cc.model.*;

@RestController
public class Bmanage {
	//contact controller层 控制contact的后台代码
	
	@Autowired
	CarService s2;
	@GetMapping("/Bmanage")
		public ModelAndView contact(){
	        ModelAndView mv = new ModelAndView("Bmanage");
	        List<Car> lists=s2.getAll();
			 mv.addObject("lists",lists);
	        return mv;
	    }
   @RequestMapping("/Bmanage")
	//@RequestParam("username") String username,@RequestParam("password") String userpassword
	    public ModelAndView contact(HttpServletRequest request,Model model, HttpSession session){
	      Car c = new Car();
	      String nowRental = "0";
	      c.setCarname(request.getParameter("carname"));
		 c.setCarprice(request.getParameter("carprice"));
		 c.setNowcar(request.getParameter("nowcar"));
		c.setNowRental(nowRental);
		if(c.getCarname()!=null) {
			   s2.insert(c);
				 ModelAndView mv = new ModelAndView("Bmanage");
				 List<Car> lists=s2.getAll();
				 mv.addObject("lists",lists);
				 return mv;
		}
		else {
			c.setId(Integer.parseInt(request.getParameter("id")));
			s2.delect(c.getId());
			ModelAndView mv = new ModelAndView("Bmanage");
			 List<Car> lists=s2.getAll();
			 mv.addObject("lists",lists);
			 return mv;  
		}
			
			
	
    
 

}}