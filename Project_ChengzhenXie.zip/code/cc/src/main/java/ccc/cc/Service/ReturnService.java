package ccc.cc.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ccc.cc.Dao.AdminDao;
import ccc.cc.Dao.ReturnDao;
import ccc.cc.model.Admin;
import ccc.cc.model.Car;
import ccc.cc.model.Return;
import ccc.cc.model.User;

@Service
public class ReturnService {
	@Autowired
        ReturnDao Dao;
	public void newreturn(Return r) {
		Dao.newreturn(r);
	}
	   public List<Return> getAll(){
		   return Dao.getAll();
	   }
	   public void delete(String id) {
			Dao.delete(id);
		}
}
