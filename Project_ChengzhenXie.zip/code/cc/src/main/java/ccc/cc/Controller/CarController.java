package ccc.cc.Controller;



import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;



import ccc.cc.Service.*;
import ccc.cc.model.*;

@RestController
public class CarController {
	@Autowired
	CarService s2;
	@Autowired
	CarrentalService s;
	
	@GetMapping("/Services")
	    
		public ModelAndView login(){
		 ModelAndView mv = new ModelAndView("Services");
	/*	 List<Car> lists = s2.getAll();;
    	
    	 System.out.print("？？？？？？？？？？？？？？？");
    	 System.out.print(lists.get(0));
    	 System.out.print(lists.get(0).getCarname());
    	 System.out.print(lists.get(0).getCarimg());
    	 System.out.print("？？？？？？？？？？？？？？？");
    	  mv.addObject("lists",lists);*/
	        return mv;
	    }
	  @RequestMapping("/Services")
		//@RequestParam("username") String username,@RequestParam("password") String userpassword
		    public ModelAndView contact(HttpServletRequest request,Model model, HttpSession session){
		      
			 
			   String string = (String)session.getAttribute("username");
				 Car c = new Car();
				 c.setCarname(request.getParameter("carname"));				
				 c.setCarseat(request.getParameter("carseat"));
				 //c.setUserid(string);
			//	c.setMsg(request.getParameter("msg"));
				 Car car2 = new Car();
				
				 List<Car> lists= s2.getname(c.getCarname(), c.getCarseat());
				System.out.println("？？？？？？？");
				 System.out.println(c.getCarname()); 
				 System.out.println("？？？？？？？");
				 System.out.println(c.getCarseat()); 
				 System.out.println("？？？？？？？");
				 System.out.println(string); 
				 System.out.println(lists);
			
				
					 ModelAndView mv = new ModelAndView("Services1");
					  mv.addObject("lists",lists);
					 return mv;   
			
				   
		
		
				   }
	    
	 
   
}