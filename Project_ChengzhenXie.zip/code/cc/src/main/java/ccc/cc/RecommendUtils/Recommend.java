package ccc.cc.RecommendUtils;

import java.util.ArrayList;
import java.util.List;

public class Recommend {

	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
		list.add("p1");
		list.add("p2");
		list.add("p3");
		list.add("p4");
		list.add("p5");
		List<Recommendmodel> simlist  = new ArrayList<Recommendmodel>();
		RecommendUtils test = new RecommendUtils();
		for(int i=0;i<list.size();i++) {
			Recommendmodel Psort = new Recommendmodel();
			if(list.get(i).equals("p1")) {
				System.out.println("sim car pass");
			}else {
				double num = test.sim_people("p1", list.get(i));
				System.out.println("p1 sim"+list.get(i)+"value:"+num);
			Psort.setSim(num);
			Psort.setUserid(list.get(i));
			System.out.println("get new person:"+Psort.getUserid());
			System.out.println("get new person sim:"+Psort.getSim());
			simlist.add(Psort);
			}
		}
        for(int m=0;m<simlist.size();m++) {
        	System.out.println("get new list:"+simlist.get(m).getUserid());
        	System.out.println("get new list sim:"+simlist.get(m).getSim());
        }
        for(int i=0;i<simlist.size()-1;i++) {
        	for(int j=0;j<simlist.size()-1;j++) {
        		if(simlist.get(j).getSim()<simlist.get(j+1).getSim()) {
        			int id = simlist.get(j).getId();
        			double hotnumber = simlist.get(j).getSim();
        			simlist.get(j).setId(simlist.get(j+1).getId());
        			simlist.get(j).setSim(simlist.get(j+1).getSim());
        			simlist.get(j+1).setId(id);
        			simlist.get(j+1).setSim(hotnumber);        		}
        	}
        }
        for(int m=0;m<simlist.size();m++) {
        	System.out.println("end rank :"+simlist.get(m).getUserid());
        	System.out.println("end rank :"+simlist.get(m).getSim());
        }
        //cf get
        for(int m=0;m<2;m++) {
        	System.out.print("cf get:"+simlist.get(m).getUserid());
        }
	}

}
