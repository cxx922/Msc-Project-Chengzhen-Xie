package ccc.cc.Dao;

import org.apache.ibatis.annotations.Mapper;

import ccc.cc.model.Admin;



@Mapper
public interface AdminDao {
//	void newuser(User u);
	Admin getPersonByname(String name);

}
