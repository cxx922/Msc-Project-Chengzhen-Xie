package ccc.cc.model;

import com.mysql.cj.jdbc.Blob;

public class Car {
	private int id;
	private String carimg;
	private String carname;
	private String carprice;
	private String nowcar;
	private String nowRental;
	private String carseat;
	public String getCarseat() {
		return carseat;
	}
	public void setCarseat(String carseat) {
		this.carseat = carseat;
	}
	public String getNowcar() {
		return nowcar;
	}
	public void setNowcar(String nowcar) {
		this.nowcar = nowcar;
	}
	public String getNowRental() {
		return nowRental;
	}
	public void setNowRental(String nowRental) {
		this.nowRental = nowRental;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public String getCarimg() {
		return carimg;
	}
	public void setCarimg(String carimg) {
		this.carimg = carimg;
	}
	public String getCarname() {
		return carname;
	}
	public void setCarname(String carname) {
		this.carname = carname;
	}
	public String getCarprice() {
		return carprice;
	}
	public void setCarprice(String carprice) {
		this.carprice = carprice;
	}

	


}
