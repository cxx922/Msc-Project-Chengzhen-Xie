Required environment:
Language: Java1.8 or higher
IDE: Eclipse2019-09
Framework: Springboot
Database: mysql5.7+navicat
The rest: install in order according to pom.xml

