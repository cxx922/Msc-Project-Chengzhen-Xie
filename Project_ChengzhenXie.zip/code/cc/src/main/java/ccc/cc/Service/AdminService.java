package ccc.cc.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ccc.cc.Dao.AdminDao;
import ccc.cc.model.Admin;
import ccc.cc.model.User;

@Service
public class AdminService {
	@Autowired
	AdminDao Dao;
	 public Admin getPersonByname(String name){
	       return Dao.getPersonByname(name);
	   }
}
