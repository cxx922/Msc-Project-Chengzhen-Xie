package ccc.cc.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ccc.cc.Dao.*;
import ccc.cc.model.*;
@Service
public class Testservice {
	@Autowired
   TestDao test;
   public List<User> getAll(){
	   return test.getAll();
   }
   
   //登陆注册
   public void newp(User p){
      test.newuser(p);
   }
   public User getPersonByname(String name){
       return test.getPersonByname(name);
   }
   public void upadateuser(User u) {
	   test.updateuser(u);
   }
   public void deleteuser(int id) {
	   test.deleteuser(id);
   }
   public void updatepassword(User u) {
	   test.updatepassword(u);
   }

}
