package ccc.cc.Dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;


import ccc.cc.model.*;

@Mapper
public interface TestDao {
	
	//查询所有的人
List<User> getAll();

//登陆
//注册
void newuser(User u);
User getPersonByname(String name);
void updateuser(User u);
void deleteuser(int id);
void updatepassword(User u);
}
