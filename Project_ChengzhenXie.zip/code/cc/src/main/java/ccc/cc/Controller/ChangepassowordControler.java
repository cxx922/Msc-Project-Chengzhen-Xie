package ccc.cc.Controller;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import ccc.cc.Service.*;
import ccc.cc.model.*;

@RestController
public class ChangepassowordControler {
	@Autowired
	Testservice ts;
    @RequestMapping("/changepassword")
	    public ModelAndView changepassword(HttpServletRequest request, Model model,HttpSession session){
		   User u = new User();
		   String username = request.getParameter("username");
		   String password = request.getParameter("password");
		   String newpassword = request.getParameter("newpassword");
		   String Confirmnewpassword = request.getParameter("Confirmnewpassword");
		   u = ts.getPersonByname(username);
		   System.out.print("?");
		   if(Confirmnewpassword.equals(newpassword)) {
			   if(u.getPassword().equals(password)) {
				   u.setPassword(newpassword);
				   ts.updatepassword(u);
				   ModelAndView mv = new ModelAndView("login");
				    return mv;
			   }else {	
				   model.addAttribute("msg1", "wrong input password");
				   ModelAndView mv = new ModelAndView("forget");
				    return mv;
			   }
		   }else {
			   model.addAttribute("msg1", "wrong input newpassword");
			   ModelAndView mv = new ModelAndView("forget");
			   return mv;
		   }

		   
		   
    }
}