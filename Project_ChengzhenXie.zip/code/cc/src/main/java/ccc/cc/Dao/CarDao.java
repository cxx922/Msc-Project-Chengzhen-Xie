package ccc.cc.Dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import ccc.cc.model.Car;
import ccc.cc.model.User;
@Mapper
public interface CarDao {
	
	//查询所有的人
List<Car> getAll();
Car getid(int id);
void update(Car c); 
void insert(Car c);
void delect(int id);
List<Car> getname(@Param("carname")String carname,@Param("carseat")String carseat);

}
