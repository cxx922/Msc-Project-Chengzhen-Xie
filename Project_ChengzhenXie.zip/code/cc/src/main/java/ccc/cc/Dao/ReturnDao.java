package ccc.cc.Dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import ccc.cc.model.Car;
import ccc.cc.model.Contact;
import ccc.cc.model.Return;
import ccc.cc.model.User;

@Mapper
public interface ReturnDao {
//contact接口类 方法
	void newreturn(Return r);
	List<Return> getAll();
	void delete(String id);
}
