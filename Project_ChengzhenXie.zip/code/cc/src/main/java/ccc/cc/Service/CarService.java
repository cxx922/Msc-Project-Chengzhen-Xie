package ccc.cc.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ccc.cc.Dao.CarDao;
import ccc.cc.Dao.TestDao;
import ccc.cc.model.Car;
import ccc.cc.model.Carrental;
import ccc.cc.model.User;

@Service
public class CarService {
	@Autowired
   CarDao Dao;
   public List<Car> getAll(){
	   return Dao.getAll();
   }
  public void update(Car c) {
	   Dao.update(c);
  }
  public Car getid(int id) {
	  return Dao.getid(id);
  }
public void insert(Car c) {
	 Dao.insert(c);
}
public void delect(int id) {
	Dao.delect(id);
}
public List<Car> getname(String carname,String carseat){
	return Dao.getname(carname, carseat);
}

}
