package ccc.cc.Dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import ccc.cc.model.Carrental;


@Mapper
public interface CarrentalDao {
   void  dingdan(Carrental c);
   List<Carrental> getAll();
   Carrental getone(int id);
  void  update(Carrental c);
 List<Carrental> userrental(String userid);
void update2(Carrental c);
void delete(int id);
}
