package ccc.cc.Controller;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import ccc.cc.Service.*;
import ccc.cc.model.*;

@RestController
public class AdminController {
	@Autowired
	AdminService ts;
	@GetMapping("/admin")
		public ModelAndView login(){
	        ModelAndView mv = new ModelAndView("admin");
	        return mv;
	    }
    @RequestMapping("/admin")
	//@RequestParam("username") String username,@RequestParam("password") String userpassword
	    public ModelAndView admin(HttpServletRequest request, Model model,HttpSession session){
	      
			int vali=3;
			  Admin u = new Admin();
			   u.setUsername(request.getParameter("username"));
			   u.setPassword(request.getParameter("password"));
			
	
			  Admin u2 = new Admin();
			   u2 = ts.getPersonByname(u.getUsername());
	 
		//	   System.out.println(u2.getUsername());
		//	   System.out.println(u2.getPassword());
		  //     session.setAttribute("name", 1);
			   if(u2.getPassword()!=null&&u2.getUsername()!=null) {
				   if(u.getPassword().equals(u2.getPassword())) {
					   session.setAttribute("username", request.getParameter("username")); 
					
					   ModelAndView mv = new ModelAndView("back");
					    return mv;
					   }else if(!u.getPassword().equals(u2.getPassword())){
					 //      model.addAttribute("msg", "密码错误");
						   ModelAndView mv = new ModelAndView("login");
						   model.addAttribute("msg1", "wrongpassword");
					        return mv;   
					   }else {
						   ModelAndView mv = new ModelAndView("login");
						   model.addAttribute("msg1", "wrongpassword");
					        return mv;   
					   }
			   }else {
				   ModelAndView mv = new ModelAndView("login");
				   model.addAttribute("msg1", "wrongpassword");
			        return mv; 
			   }
			   
	
	
			   }
     public int validate(User u) {
    	 if(u.getPassword()==null&&u.getUsername()==null) {
    		 return 1;
    	 }else {
    		 return 0;
    	 }
     }
        	
 

}