package ccc.cc.Controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import ccc.cc.Service.*;
import ccc.cc.model.*;

@RestController
public class Brental {
	//Brental controller层 
	@Autowired
	CarrentalService  ts;
	@Autowired
	CarService  ts2;
	@GetMapping("/Brental")
		public ModelAndView contact(Model model){
	        ModelAndView mv = new ModelAndView("Brental");  
	        List<Carrental> lists2=ts.getAll();
	        List<Carrental> lists = new ArrayList<Carrental>();
	        List<Carrental> lists3 = new ArrayList<Carrental>();
	        System.out.print("数组大小为：");
	        System.out.print(lists2.size());
	         System.out.print(" 第一个state：");
	        System.out.print(lists2.get(0).getState());
	     //   lists.add(lists2.get(0));
	        System.out.print(" list 添加后");
	       // System.out.print(lists.get(0));
	       for(int i=0;i<lists2.size();i++) {
	        	  if(lists2.get(i).getState().equals("No")) {
	        		  lists.add(lists2.get(i));
	        	  }else {
	        		  lists3.add(lists2.get(i));
	        	  }
	        }
	      
			  mv.addObject("lists",lists);
			  mv.addObject("lists3",lists3);
	        return mv;
	}  @RequestMapping("/Brental")
	//@RequestParam("username") String username,@RequestParam("password") String userpassword
    public ModelAndView contact(HttpServletRequest request,Model model, HttpSession session){
      
	 
	   String string = (String)session.getAttribute("Brental");
		  Carrental c= new Carrental();
		  int id=Integer.parseInt(request.getParameter("Rentalid"));
		  c.setId(id);
		  c.setState("yes");
		  ts.update(c);
		  Carrental c2 = new Carrental();
		 c2 = ts.getone(id);
		int carid = Integer.parseInt(c2.getCarid());
	      Car car = new Car();
	      car = ts2.getid(carid);
	     int nowcar = Integer.parseInt( car.getNowcar());
	     int nowRental = Integer.parseInt( car.getNowRental());
	     System.out.println("????");
	     System.out.print(nowcar);
	     System.out.println("????");
	     System.out.print(nowRental);
	     System.out.println("????");
	     if(nowcar>nowRental) {
	    	 nowRental= nowRental+ 1 ;
	    	 String s =String.valueOf(nowRental);
	    	 car.setNowRental(s);
		     ts2.update(car);
			  ModelAndView mv = new ModelAndView("Brental");
		  
		        List<Carrental> lists2=ts.getAll();
		        List<Carrental> lists = new ArrayList<Carrental>();
		        List<Carrental> lists3 = new ArrayList<Carrental>();
		     //   System.out.print("数组大小为：");
		        System.out.print(lists2.size());
		     //    System.out.print(" 第一个state：");
		        System.out.print(lists2.get(0).getState());
		        lists.add(lists2.get(0));
		     //   System.out.print(" list 添加后");
		       // System.out.print(lists.get(0));
		       for(int i=0;i<lists2.size();i++) {
		        	  if(lists2.get(i).getState().equals("No")) {
		        		  lists.add(lists2.get(i));
		        	  }else {
		        		  lists3.add(lists2.get(i));
		        	  }
		        }
				  mv.addObject("lists",lists);
				  mv.addObject("lists3",lists3);
				  return mv;
	     }else {
	    	  ModelAndView mv = new ModelAndView("Brental");
	          List<Carrental> lists2=ts.getAll();
		        List<Carrental> lists = new ArrayList<Carrental>();
		        List<Carrental> lists3 = new ArrayList<Carrental>();
		        System.out.print("数组大小为：");
		        System.out.print(lists2.size());
		         System.out.print(" 第一个state：");
		        System.out.print(lists2.get(0).getState());
		     //   lists.add(lists2.get(0));
		        System.out.print(" list 添加后");
		       // System.out.print(lists.get(0));
		       for(int i=0;i<lists2.size();i++) {
		        	  if(lists2.get(i).getState().equals("No")) {
		        		  lists.add(lists2.get(i));
		        	  }else {
		        		  lists3.add(lists2.get(i));
		        	  }
		        }
		      
				  mv.addObject("lists",lists);
				  mv.addObject("lists3",lists3);
				  return mv;
			     
	     }
	
		
	
		
			 
	
	
		   


		   }



}
			  
    
 

