package ccc.cc.Controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import ccc.cc.Service.*;
import ccc.cc.model.*;

@RestController
public class BcontactController {
	//contact controller层 控制contact的后台代码
	@Autowired
	ContactService ts;
	@GetMapping("/Bcontact")
		public ModelAndView contact(){
	        ModelAndView mv = new ModelAndView("Bcontact");
	        List<Contact> lists=ts.getAll();
			  mv.addObject("lists",lists);
	        return mv;
	    }
   @RequestMapping("/Bcontact")
	//@RequestParam("username") String username,@RequestParam("password") String userpassword
	    public ModelAndView contact(HttpServletRequest request,Model model, HttpSession session){
	      
		 
		   String string = (String)session.getAttribute("username");
			  Contact c  = new Contact();
			c.setUserid(string);
			c.setMsg(request.getParameter("msg"));
			
			 System.out.println("？？？？？？？");
			 System.out.print(session.getAttribute("username")); 
			 System.out.println("？？？？？？？");
			 ModelAndView mv = new ModelAndView("Bcontact");
			 return mv;  
			
	
			   }
    
 

}