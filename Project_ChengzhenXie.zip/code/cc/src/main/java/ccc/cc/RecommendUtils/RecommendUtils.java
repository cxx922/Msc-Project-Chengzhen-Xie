package ccc.cc.RecommendUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class RecommendUtils {

	//set up public dictionary
	private Map<String,Map<String,Double>> dataset = null ;
	
	//initializing method RecommendUtils
    public RecommendUtils() {
       iniData();
    }
    //initializing dataset
    private void iniData() {
    	dataset = new HashMap<String,Map<String,Double>>();
    	//dataset test1
    	Map<String,Double> map1 =  new HashMap<String,Double>();
    	map1.put("car1",3.0);
    	map1.put("car2",4.0);
    	map1.put("car3", 4.5);
    	map1.put("car4", 3.5);
    	map1.put("car5", 3.5);
    	map1.put("car6",5.0);
    	dataset.put("p1",map1);
    	
    	//dataset test2
    	Map<String,Double> map2 =  new HashMap<String,Double>();
    	map2.put("car1",4.0);
    	map2.put("car2",3.5);
    	map2.put("car3", 4.5);
    	map2.put("car5", 1.5);
    	map2.put("car6", 3.5);
    	map2.put("car7",2.0);
    	dataset.put("p2",map2);
    	
    	//dataset test3
    	Map<String,Double> map3 =  new HashMap<String,Double>();
    	map3.put("car2",3.0);
    	map3.put("car3",3.5);
    	map3.put("car4", 1.5);
    	map3.put("car5", 3.5);
    	map3.put("car6", 4.5);
    	map3.put("car8",5.0);
    	map3.put("car9",3.0);
    	dataset.put("p3",map3);
    	

    	//dataset test4
    	Map<String,Double> map4 =  new HashMap<String,Double>();
    	map4.put("car2",2.5);
    	map4.put("car3",4.5);
    	map4.put("car4", 2.5);
    	map4.put("car5", 4.0);
    	map4.put("car6", 3.5);
    	map4.put("car8",4.0);
    	map4.put("car9",5.0);
    	dataset.put("p4",map4);
    	
    	//dataset test5
    	Map<String,Double> map5 =  new HashMap<String,Double>();
    	map5.put("car2",3.5);
    	map5.put("car3",5.0);
    	map5.put("car4", 2.5);
    	map5.put("car5", 3.5);
    	map5.put("car6", 4.5);
    	map5.put("car8",4.5);
    	map5.put("car9",5.0);
    	dataset.put("p5",map5);
    }
    //return your data
    public Map<String,Map<String,Double>> getDateset(){
    	return dataset;
    }
    //similarity calculation
    public double sim_people(String person1,String person2) {
    //find the sim 	cardata
    List<String> list = new ArrayList<String>();
    for(Entry<String,Double>p1:dataset.get(person1).entrySet()) {
    	if(dataset.get(person2).containsKey(p1.getKey())){
    		list.add(p1.getKey());
    	}
    }
    //pearson calculation
    double sumX = 0.0;
    double sumY = 0.0;
    double sumX_Sq = 0.0;
    double sumY_Sq = 0.0;
    double sumXY = 0.0;
    int N = list.size();
    for(String name:list) {
    	Map<String,Double> p1Map = dataset.get(person1);
    	Map<String,Double> p2Map = dataset.get(person2);
    	sumX += p1Map.get(name);
    	sumY += p2Map.get(name);
    	sumX_Sq += Math.pow(p1Map.get(name),2);
    	sumY_Sq += Math.pow(p2Map.get(name),2);
    	sumXY += p1Map.get(name)*p2Map.get(name);
    }
    double top = sumXY - sumX * sumY /N;
    double down = Math.sqrt((sumX_Sq-sumX*sumX/N)*(sumY_Sq-sumY*sumY/N));
    if(down == 0) {
    	 return 0;
    }
    return top / down ;
    }
}
