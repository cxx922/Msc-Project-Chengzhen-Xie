package ccc.cc.Controller;



import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;



import ccc.cc.Service.*;
import ccc.cc.model.*;

@RestController
public class BcarController {
	@Autowired
	CarService s2;
	@Autowired
	CarrentalService s;
	
	@GetMapping("/Bcar")
	    
		public ModelAndView login(){
		 List<Car> lists = s2.getAll();;
    	 ModelAndView mv = new ModelAndView("Bcar");
    	 System.out.print("？？？？？？？？？？？？？？？");
    	 System.out.print(lists.get(0));
    	 System.out.print(lists.get(0).getCarname());
    	 System.out.print(lists.get(0).getCarimg());
    	 System.out.print("？？？？？？？？？？？？？？？");
    	  mv.addObject("lists",lists);
	        return mv;
	    }
	
	    
	 
   
}