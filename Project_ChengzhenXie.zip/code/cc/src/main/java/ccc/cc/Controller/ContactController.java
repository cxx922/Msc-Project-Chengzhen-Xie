package ccc.cc.Controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import ccc.cc.Service.*;
import ccc.cc.model.*;

@RestController
public class ContactController {
	//contact controller层 控制contact的后台代码
	@Autowired
	ContactService ts;
	@GetMapping("/contact")
		public ModelAndView contact(){
	        ModelAndView mv = new ModelAndView("contact");
	        
	        return mv;
	    }
    @RequestMapping("/contact")
	//@RequestParam("username") String username,@RequestParam("password") String userpassword
	    public ModelAndView contact(HttpServletRequest request,Model model, HttpSession session){
	      
		 
		   String string = (String)session.getAttribute("username");
			  Contact c  = new Contact();
			c.setUserid(string);
			c.setMsg(request.getParameter("msg"));
			ts.newmsg(c);
			 System.out.println("？？？？？？？");
			 System.out.print(session.getAttribute("username")); 
			 System.out.println("？？？？？？？");
			//   u.setUsername(request.getParameter("username"));
		//	   u.setPhone(request.getParameter("phone"));
		
		
			/*   System.out.println("????????");
			   System.out.println(u.getUsername());
			   System.out.println(u.getPassword());*/
		/*	  if(u.getPassword().length()>8) {
				  
			   model.addAttribute("msg1", "Please input the account number and password below 8 digits");
			   ModelAndView mv = new ModelAndView("reg");
				 return mv;   
			  }else if(u.getUsername().length()>8){
				  model.addAttribute("msg1", "Please input the account number and password below 8 digits");
				  ModelAndView mv = new ModelAndView("reg");
				  return mv; 
			  }*/
		
			   System.out.println("？？？？？？？");
		//	   System.out.println(u2.getUsername());
		//	   System.out.println(u2.getPassword());
		 //      session.setAttribute("name", 1);
			   model.addAttribute("msg1", "Thank you for your advice");
				 ModelAndView mv = new ModelAndView("contact");
				 return mv;   
		
			   
	
	
			   }
    
 

}