package ccc.cc.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ccc.cc.Dao.CarrentalDao;
import ccc.cc.model.Carrental;


@Service
public class CarrentalService {
	@Autowired
	CarrentalDao dao;
	public void dingdan(Carrental c) {
		dao.dingdan(c);
	}
	 public List<Carrental> getAll(){
		   return dao.getAll();
	   } 
	  public void update(Carrental c) {
		   dao.update(c);
	   }
	  public void update2(Carrental c) {
		   dao.update2(c);
	   }
	 public Carrental getone(int id) {
		 return dao.getone(id);
	 }
	 public List<Carrental> userrental(String userid) {
		 return dao.userrental(userid);
	 }
	 public void delete(int id) {
			dao.delete(id);
		}
}
