package ccc.cc.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import ccc.cc.Service.ContactService;
import ccc.cc.Service.Testservice;
import ccc.cc.model.Contact;
import ccc.cc.model.User;
@RestController
public class InformationController {
	//contact controller层 控制contact的后台代码
	@Autowired
	Testservice t;
	@GetMapping("/information")
		public ModelAndView information(){
	        ModelAndView mv = new ModelAndView("information");
	        
	        return mv;
	    }
    @RequestMapping("/information")
	   public ModelAndView contact(HttpServletRequest request,Model model, HttpSession session){
		      
			 
		   String string = (String)session.getAttribute("username");
		   User u = new User();
		   u.setUsername(string);
		   u.setSex(request.getParameter("sex"));
		   u.setIdcard(request.getParameter("idcard"));
           u.setAddress(request.getParameter("address"));	
           String idcard = request.getParameter("idcard");
           String sex = request.getParameter("sex");
           System.out.print("sssssssssss");
           System.out.print(idcard.length());
           System.out.print("sssssssssss");
           int length = idcard.length();
		  if(string == null) {
			  ModelAndView mv = new ModelAndView("information");
				
			  model.addAttribute("msg1", "plz login"); return mv;  
		  }else {
			  if(length<18) {
				  ModelAndView mv = new ModelAndView("information");
				  model.addAttribute("msg1", "idcard inputwrong"); return mv;
			  }
			  if(length>18) {
				  ModelAndView mv = new ModelAndView("information");
				  model.addAttribute("msg1", "idcard inputwrong"); return mv;
			  }
			  else  {
				  t.upadateuser(u);
				  model.addAttribute("msg1", "success!");
				  ModelAndView mv = new ModelAndView("information");
					 return mv;   
			  }
		      
		  }
			  
				
			   
	
	
			   }
    
 

}