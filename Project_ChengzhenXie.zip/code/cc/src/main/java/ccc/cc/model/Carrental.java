package ccc.cc.model;

public class Carrental {
	private int id;
	private String userid;
	private String carid;
	private String cartianshu;
	private String state;
	private String cartianshu2;
	public String getCartianshu2() {
		return cartianshu2;
	}
	public void setCartianshu2(String cartianshu2) {
		this.cartianshu2 = cartianshu2;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getCarid() {
		return carid;
	}
	public void setCarid(String carid) {
		this.carid = carid;
	}
	public String getCartianshu() {
		return cartianshu;
	}
	public void setCartianshu(String cartianshu) {
		this.cartianshu = cartianshu;
	}
	
	
}
