package ccc.cc.Dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import ccc.cc.model.Contact;
import ccc.cc.model.User;

@Mapper
public interface ContactDao {
//contact接口类 方法
	void newmsg(Contact c);
	List<Contact> getAll();
}
