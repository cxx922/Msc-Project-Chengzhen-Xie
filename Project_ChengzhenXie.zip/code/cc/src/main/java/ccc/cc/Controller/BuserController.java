package ccc.cc.Controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import ccc.cc.Service.*;
import ccc.cc.model.*;

@RestController
public class BuserController {
	//contact controller层 控制contact的后台代码
	
	@Autowired
	Testservice s2;
	@GetMapping("/Buser")
		public ModelAndView contact(){
	        ModelAndView mv = new ModelAndView("Buser");
	        List<User> lists=s2.getAll();
			 mv.addObject("lists",lists);
	        return mv;
	    }
  @RequestMapping("/Buser")
	//@RequestParam("username") String username,@RequestParam("password") String userpassword
	    public ModelAndView contact(HttpServletRequest request,Model model, HttpSession session){
	 User u = new User();
	 String id =  request.getParameter("userid");
	
	 int id2 = Integer.parseInt(id);
	 System.out.print(id2);
	 System.out.print("id2idid2id2id2id2id2id2id2id2id2id2id2id2id2id2id2id22");
	  u.setId(id2);
	  s2.deleteuser(id2);
	  ModelAndView mv = new ModelAndView("Buser");
      List<User> lists=s2.getAll();
		 mv.addObject("lists",lists);
      return mv;
	  }
			
			
	
    
 

}