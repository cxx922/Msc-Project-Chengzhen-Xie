package ccc.cc.Controller;



import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;



import ccc.cc.Service.*;
import ccc.cc.model.*;

@RestController
public class Services1Controller {
	@Autowired
	CarService s2;
	@Autowired
	CarrentalService s;
	//@Autowired
	
	
	@GetMapping("/Services1")
	    
		public ModelAndView service1(){
		 ModelAndView mv = new ModelAndView("Services1");
	/*	 List<Car> lists = s2.getAll();;
    	
    	 System.out.print("？？？？？？？？？？？？？？？");
    	 System.out.print(lists.get(0));
    	 System.out.print(lists.get(0).getCarname());
    	 System.out.print(lists.get(0).getCarimg());
    	 System.out.print("？？？？？？？？？？？？？？？");
    	  mv.addObject("lists",lists);*/
	        return mv;
	    }
	  @RequestMapping("/Services1")
		//@RequestParam("username") String username,@RequestParam("password") String userpassword
		    public ModelAndView contact(HttpServletRequest request,Model model, HttpSession session){
		      
			 
			   String string = (String)session.getAttribute("username");
			   String carid = request.getParameter("carid");
				Carrental c = new Carrental();
				c.setUserid(string);
				c.setCarid(request.getParameter("carid"));
				c.setState("No");
				c.setCartianshu(request.getParameter("carday"));
				c.setCartianshu2(request.getParameter("carday2"));
				 //c.setUserid(string);
			//	c.setMsg(request.getParameter("msg"));
				Car c2 = new Car();
			    c2=s2.getid(Integer.parseInt(carid));
			   System.out.println("ssssssssssssss");
			   System.out.println(c2.getNowcar());
			   System.out.println(c2.getNowRental());
			    int nowcar = Integer.parseInt(c2.getNowcar());
			    int nowrent = Integer.parseInt(c2.getNowRental());
				if(nowrent<nowcar) {

					 ModelAndView mv = new ModelAndView("Services");
						s.dingdan(c);	
					// mv.addObject("lists",lists);
					 return mv;   
				
				}else {

					 ModelAndView mv = new ModelAndView("Services1");
						model.addAttribute("msg1","Out of Stock");
					// mv.addObject("lists",lists);
					 return mv;   
				
				}
				
/*				System.out.println("？？？？？？？");
				 System.out.println(c.getCarname()); 
				 System.out.println("？？？？？？？");
				 System.out.println(c.getCarseat()); 
				 System.out.println("？？？？？？？");
				 System.out.println(string); 
				 System.out.println(lists);
			*/
				
			
				   
		
		
				   }
	    
	 
   
}