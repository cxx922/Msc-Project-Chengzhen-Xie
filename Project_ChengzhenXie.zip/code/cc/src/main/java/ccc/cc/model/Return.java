package ccc.cc.model;

public class Return {
	private int id;
	private String rentalid;
	private String userid;
	private String state;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRentalid() {
		return rentalid;
	}
	public void setRentalid(String rentalid) {
		this.rentalid = rentalid;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	

}
